## xls2json

```bash
xls2json [--perentry] [--persheet] xls_input [output_path='output']
```

Take XLS file and write to JSON file(s) (single, one for every row, and/or one for every workbook sheet).

### Requirements

- xlrd

### Installation

```bash
pip3 install xls2json
```

## TODO

- compatibility with json2xls


<!-- [tbmreza-json2xls]() -->