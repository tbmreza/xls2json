import xls2json

def main():
    xls2json.main()